library(shiny)

shinyUI(fluidPage(
  titlePanel("Web application")
))
